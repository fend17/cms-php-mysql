<?php
  //Set the title of the page, the title is used in 'head.php'
  $title = "About";
  include 'partials/head.php';
  include 'partials/header.php';
  include 'partials/nav.php';
?>
  <main>
    <h2> <?= $title ?> </h2>
  </main>

<?php include 'partials/footer.php'; ?>