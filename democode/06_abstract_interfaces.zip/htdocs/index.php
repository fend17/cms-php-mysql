<?php
require_once 'partials/head.php';
// require_once 'classes/Elephant.php';
// require_once 'classes/ElephantController.php';

// $hathi = new Elephant("Hathi", 500);
// $mowgli = new Elephant("Mowgli", 5);

// $herd = new ElephantController();
// $herd->addElephant($hathi);
// pretty($herd->getElephants()[0]->getName());

interface CanJumpInterface
{
    public function jump();
    public function jumpHigh();
}

interface MultiplyInterface
{
    public function multiplyNumbersReallyEasySoEasy();
}

abstract class Animal
{
    protected $name;
    protected $isAlive = true;
    public function __construct($name)
    {
        $this->name = $name;
    }
    public function speak()
    {
        echo "Speak";
    }
    abstract public function eat();
}

class Elephant extends Animal implements CanJumpInterface, MultiplyInterface
{
    protected $tusks = true;
    // Override method

    public function speak()
    {
        echo "tut tut elephanty!!<br/>";
    }
    public function getIsAlive()
    {
        return $this->isAlive;
    }
    public function eat()
    {
        echo "NOM NOM!!!!!!";
    }
    public function jump()
    {
    }
    public function jumpHigh()
    {
    }
    public function multiplyNumbersReallyEasySoEasy()
    {
    }
}

$an_elephant = new Elephant("Hathi");
$an_elephant->speak();









// DRY    - Don't Repeat Yourself
// KISS   - Keep It Simple Stupid
// YAGNI  - You Ain't Gonna Need It


/**
 * SOLID
 * Single Resposibility
 * Open Closed Principle
 * Liskov Substitution Principle
 * Interface Segregation
 * Dependency Inversion
 */
 
class Calculator
{
    // Abstraction
    public static function add($a, $b)
    {
        // Implementation
        $result = $a + $b;
        return $result;
    }
    public static function subtract($a, $b)
    {
        return $a - $b;
    }
}

// API methods/functions
Calculator::add(10, 10);
Calculator::add(20, 20);

require 'partials/footer.php';
