<header>
  <h1> Frontend Blog </h1>
</header>