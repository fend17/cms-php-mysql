<?php
require_once 'partials/head.php';
require_once 'classes/Elephant.php';
require_once 'classes/ElephantController.php';

$hathi = new Elephant("Hathi", 500);
$mowgli = new Elephant("Mowgli", 5);

$herd = new ElephantController();
$herd->addElephant($hathi);
var_dump($herd->getElephants());

// echo '<br/>';
// echo Elephant::$legs;
// Elephant::poop();

// $ArrayHelper = new ArrayHelper($my_array);
// $ArrayHelper->dumpAndDie();

// ArrayHelper::prettyPrint([]);
// ArrayHelper::dumpAndDie([]);

require 'partials/footer.php';
