<div class="reviews">
  <h2>
    <?= $review["name"]; ?>
  </h2>
  <p>
    <?= $review["body"]; ?>
  </p>
</div>