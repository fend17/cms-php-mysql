<?php
require 'partials/head.php';

// Reviews for the Hotel: PHP Hotel
$reviews = require 'partials/review_data.php';

/**
 * Echo way of printing the same data as below
 */
// foreach($reviews as $review){
//   echo "<div class=\"reviews\">";
//   echo "<h2>" . $review["name"] . "</h2>";
//   echo "<p>" . $review["body"] . "</p>";
//   echo "</div>";
// }

/**
 * foreach(): endforeach; is the same as foreach(){}
 * if(): endif; is the same as if(){} 
 */
foreach($reviews as $review): 
  if($review["name"] === "Hilda"):
    /**
     * We include the php-file multiple times, this is fine
     * because it is just HTML, no functions or variables
     * are being redeclared
     */
    include 'partials/review_card.php';
  endif;
endforeach;

require 'partials/footer.php'; ?>
