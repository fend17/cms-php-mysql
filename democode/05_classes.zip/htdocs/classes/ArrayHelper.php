<?php

class ArrayHelper
{
    public $array;
    public function __construct($array)
    {
        $this->array = $array;
    }
    public function prettyPrint()
    {
        return highlight_string("<?php\n\$data =\n" . var_export($this->array, true) . ";\n?>");
    }
    public function dumpAndDie()
    {
        die(var_dump($this->array));
    }
}

class ArrayHelper
{
    public static function prettyPrint($array)
    {
        return highlight_string("<?php\n\$data =\n" . var_export($array, true) . ";\n?>");
    }
    public static function dumpAndDie($array)
    {
        die(var_dump($array));
    }
}
