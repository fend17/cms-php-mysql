<?php

class Elephant
{
    private $name;
    private $age;
    private $livesInJungle;
    public static $legs = 4;

    public function __construct($newName, $newAge)
    {
        $this->name = $newName;
        $this->age = $newAge;
        $this->livesInJungle = true;
    }

    public static function poop()
    {
        echo "hnnnnnng!!!!";
    }

    public function speak()
    {
        echo "I am " . $this->name;
    }

    public function setName($newName)
    {
        if (is_null($newName)) {
            return "Aja baja";
        } else {
            $this->name = $newName;
        }
    }
}
