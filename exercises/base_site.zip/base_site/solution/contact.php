<?php
  $title = "Contact";
  include 'partials/head.php';
  include 'partials/header.php';
  include 'partials/nav.php';
?>
  <main>
    <h2><?= $title ?></h2>
  </main>
  
<?php include 'partials/footer.php'; ?>