<footer>
  <p>Copyright Datadata</p>
</footer>
</body>
</html>