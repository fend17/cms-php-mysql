<?php
require 'partials/head.php';
echo "Hello from contact!";
require 'partials/footer.php';