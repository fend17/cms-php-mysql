<?php
require 'partials/head.php';
echo "Hello from about!";
require 'partials/footer.php';