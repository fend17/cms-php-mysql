<?php

/**
 * You can return data directly from a php file, you have to
 * save it when you require it
 */
$reviews = [
  [
    "name"  => "Hilda",
    "body"  => "I peed in the pool"
  ],
  [
    "name"  => "Morgana",
    "body"  => "The pool was very warm"
  ],
  [
    "name"  => "Goran",
    "body"  => "Nasty ass Hilda"
  ]
];
