const form = document.getElementById('example_form');

form.addEventListener('submit', function(e) {
  e.preventDefault();
  const postData = new FormData(this);
  fetchFromPHP(postData);
});

async function fetchFromPHP(body){
  /// x-www-form-urlencoded 
  const response = await fetch('handle_form.php',{
    method: 'POST',
    body: body
  });
  const responseData = await response.text();
  console.log(responseData);
}

async function fetchPokemon(){
  const response = await fetch('fetch_pokemon.php?pokemon=25');
  const pokemon = await response.json();
  console.log(pokemon);
}






class Elephant {
  speak(){
    console.log("ERRUH!");
  }
}

function Elephant(){
  
}

// method
Elephant.prototype.speak = function(){
  console.log("ERUUH");
}

// static method
Elephant.speak = function(){
  console.log("ERRUH!");
}






