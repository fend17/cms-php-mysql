<?php


echo $_POST["username"];
echo $_POST["favorite_number"];
echo $_GET["name"];
