<?php

class Animal
{
    public function speak()
    {
        echo "I change shapes just to hide in this place";
    }
}
